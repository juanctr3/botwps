<?php
/**
 * Plugin Name: BotWPS WhatsApp Sender
 * Description: Envía mensajes de WhatsApp a través de la API de Botwps.com e integra con Gravity Forms y WooCommerce.
 * Version: 1.3
 * Author: BotWPS
 * Author URI: https://botwps.com
 * License: GPL2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: botwps-whatsapp-sender
 */

// Evitar acceso directo al archivo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'BOTWPS_WHATSAPP_VERSION', '1.3' );
define( 'BOTWPS_WHATSAPP_DB_VERSION', '1.0' );
define( 'BOTWPS_WHATSAPP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BOTWPS_WHATSAPP_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Función que se ejecuta al activar el plugin.
 */
function botwps_activate_plugin() {
    botwps_create_log_table();
    add_option( 'botwps_whatsapp_version', BOTWPS_WHATSAPP_VERSION );
    add_option( 'botwps_whatsapp_db_version', BOTWPS_WHATSAPP_DB_VERSION );
}
register_activation_hook( __FILE__, 'botwps_activate_plugin' );

/**
 * Crea la tabla para el log de mensajes de WhatsApp.
 */
function botwps_create_log_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'botwps_whatsapp_log';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        recipient varchar(50) NOT NULL,
        message longtext NOT NULL,
        status varchar(20) NOT NULL, -- 'success', 'failed'
        api_response longtext DEFAULT NULL,
        source_trigger varchar(100) DEFAULT '' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

/**
 * Encola los estilos CSS para las páginas de administración del plugin.
 */
function botwps_enqueue_admin_styles( $hook_suffix ) {
    $screen = get_current_screen();
    if ( ! $screen ) {
        return;
    }

    $plugin_pages_base_ids = array(
        'toplevel_page_botwps-whatsapp-sender',       // Página principal de ajustes
        'botwps-whatsapp_page_botwps-send-whatsapp',  // Subpágina de Enviar Mensaje
        'botwps-whatsapp_page_botwps-whatsapp-log',   // Subpágina de Log de Mensajes
    );

    // Comprobación específica para la página de ajustes de Gravity Forms del plugin
    $is_gf_botwps_settings_page = ( $screen->id === 'forms_page_gf_edit_forms' && isset( $_GET['subview'] ) && $_GET['subview'] === 'botwps_whatsapp' );

    if ( in_array( $screen->id, $plugin_pages_base_ids ) || $is_gf_botwps_settings_page ) {
        wp_enqueue_style(
            'botwps-admin-styles',
            BOTWPS_WHATSAPP_PLUGIN_URL . 'assets/css/botwps-admin-styles.css',
            array(),
            BOTWPS_WHATSAPP_VERSION
        );
    }
}
add_action( 'admin_enqueue_scripts', 'botwps_enqueue_admin_styles' );


/**
 * Agrega las páginas de opciones del plugin al menú de administración.
 */
function botwps_admin_menu() {
    add_menu_page(
        __( 'BotWPS WhatsApp', 'botwps-whatsapp-sender' ),
        __( 'BotWPS WhatsApp', 'botwps-whatsapp-sender' ),
        'manage_options',
        'botwps-whatsapp-sender', // Slug de la página principal (Ajustes)
        'botwps_settings_page_html',
        'dashicons-whatsapp',
        80
    );

    add_submenu_page(
        'botwps-whatsapp-sender', // Slug del menú padre
        __( 'Enviar Mensaje WhatsApp', 'botwps-whatsapp-sender' ),
        __( 'Enviar Mensaje', 'botwps-whatsapp-sender' ),
        'manage_options',
        'botwps-send-whatsapp',
        'botwps_send_message_page_html'
    );

    add_submenu_page(
        'botwps-whatsapp-sender',
        __( 'Log de Mensajes WhatsApp', 'botwps-whatsapp-sender' ),
        __( 'Log de Mensajes', 'botwps-whatsapp-sender' ),
        'manage_options',
        'botwps-whatsapp-log',
        'botwps_render_log_page_html'
    );
    // Aquí se añadirían submenús para WooCommerce, etc.
}
add_action( 'admin_menu', 'botwps_admin_menu' );

/**
 * Registra las configuraciones del plugin.
 */
function botwps_register_settings() {
    $settings_group = 'botwps_settings_group';
    $page_slug = 'botwps-whatsapp-sender'; // Slug de la página donde se muestran estas secciones

    register_setting( $settings_group, 'botwps_api_secret', 'sanitize_text_field' );
    register_setting( $settings_group, 'botwps_whatsapp_account_id', 'sanitize_text_field' );
    register_setting( $settings_group, 'botwps_enable_failure_notify', 'absint' );
    register_setting( $settings_group, 'botwps_failure_notify_email', 'sanitize_email' );

    $api_section_id = 'botwps_api_settings_section';
    add_settings_section( $api_section_id, __( 'Configuración de API BotWPS', 'botwps-whatsapp-sender' ), null, $page_slug );
    add_settings_field( 'botwps_api_secret_field', __( 'API Secret', 'botwps-whatsapp-sender' ), 'botwps_api_secret_field_html', $page_slug, $api_section_id );
    add_settings_field( 'botwps_whatsapp_account_id_field', __( 'WhatsApp Account Unique ID', 'botwps-whatsapp-sender' ), 'botwps_whatsapp_account_id_field_html', $page_slug, $api_section_id );

    $error_notify_section_id = 'botwps_error_notification_settings_section';
    add_settings_section( $error_notify_section_id, __( 'Notificación de Errores de Envío', 'botwps-whatsapp-sender' ), null, $page_slug );
    add_settings_field( 'botwps_enable_failure_notify_field', __( 'Activar Email en Fallo', 'botwps-whatsapp-sender' ), 'botwps_enable_failure_notify_field_html', $page_slug, $error_notify_section_id );
    add_settings_field( 'botwps_failure_notify_email_field', __( 'Email para Notificar Fallos', 'botwps-whatsapp-sender' ), 'botwps_failure_notify_email_field_html', $page_slug, $error_notify_section_id );
}
add_action( 'admin_init', 'botwps_register_settings' );

/**
 * Funciones HTML para los campos de configuración.
 */
function botwps_api_secret_field_html() {
    $api_secret = get_option( 'botwps_api_secret' );
    echo '<input type="text" id="botwps_api_secret" name="botwps_api_secret" value="' . esc_attr( $api_secret ) . '" class="regular-text code" />'; // 'code' para sugerir monospace
    echo '<p class="description">' . __( 'Introduce tu API Secret de Botwps.com.', 'botwps-whatsapp-sender' ) . '</p>';
}

function botwps_whatsapp_account_id_field_html() {
    $account_id = get_option( 'botwps_whatsapp_account_id' );
    echo '<input type="text" id="botwps_whatsapp_account_id" name="botwps_whatsapp_account_id" value="' . esc_attr( $account_id ) . '" class="regular-text code" />';
    echo '<p class="description">' . __( 'Introduce el ID único de tu cuenta de WhatsApp configurada en BotWPS.', 'botwps-whatsapp-sender' ) . '</p>';
}

function botwps_enable_failure_notify_field_html() {
    $enable_failure_notify = get_option( 'botwps_enable_failure_notify', 0 );
    echo '<input type="checkbox" id="botwps_enable_failure_notify" name="botwps_enable_failure_notify" value="1" ' . checked( 1, $enable_failure_notify, false ) . ' />';
    echo '<label for="botwps_enable_failure_notify" style="margin-left: 5px;">' . __( 'Activar', 'botwps-whatsapp-sender' ) . '</label>';
    echo '<p class="description">' . __( 'Si está activado, se enviará un correo electrónico a la dirección especificada cuando falle el envío de un mensaje de WhatsApp.', 'botwps-whatsapp-sender' ) . '</p>';
}

function botwps_failure_notify_email_field_html() {
    $failure_email = get_option( 'botwps_failure_notify_email', get_option( 'admin_email' ) );
    echo '<input type="email" id="botwps_failure_notify_email" name="botwps_failure_notify_email" value="' . esc_attr( $failure_email ) . '" class="regular-text ltr" />';
    echo '<p class="description">' . __( 'Dirección de correo para recibir notificaciones si un envío de WhatsApp falla.', 'botwps-whatsapp-sender' ) . '</p>';
}

/**
 * Muestra el contenido HTML de la página principal de configuración.
 */
function botwps_settings_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap botwps-admin-page-wrap botwps-settings-page">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post" class="botwps-settings-form">
            <?php
            settings_fields( 'botwps_settings_group' );
            do_settings_sections( 'botwps-whatsapp-sender' ); // Slug de la página donde se añadieron las secciones
            submit_button( __( 'Guardar Cambios', 'botwps-whatsapp-sender' ) );
            ?>
        </form>
        <p class="botwps-page-footer-note"><strong><?php _e( 'Nota:', 'botwps-whatsapp-sender' ); ?></strong> <?php _e( 'La integración con la API de Botwps.com se basa en la información proporcionada. Asegúrate de que tus credenciales sean correctas.', 'botwps-whatsapp-sender' ); ?></p>
    </div>
    <?php
}

/**
 * Muestra el contenido HTML de la página para enviar mensajes manualmente.
 */
function botwps_send_message_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap botwps-admin-page-wrap botwps-send-message-page">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <?php
    // Manejo del envío del formulario
    if ( isset( $_POST['botwps_manual_send_nonce'] ) && wp_verify_nonce( $_POST['botwps_manual_send_nonce'], 'botwps_manual_send_action' ) ) {
        $recipient_phone = isset( $_POST['botwps_recipient_phone'] ) ? sanitize_text_field( $_POST['botwps_recipient_phone'] ) : '';
        $message_text = isset( $_POST['botwps_message_text'] ) ? sanitize_textarea_field( $_POST['botwps_message_text'] ) : '';

        if ( ! empty( $recipient_phone ) && ! empty( $message_text ) ) {
            $source_trigger = __( 'Envío Manual desde Admin', 'botwps-whatsapp-sender' );
            $result = botwps_send_actual_whatsapp_message( $recipient_phone, $message_text, $source_trigger );
            if ( $result['success'] ) {
                echo '<div id="message" class="notice notice-success is-dismissible botwps-notice"><p>' . sprintf( __( 'Mensaje de WhatsApp enviado exitosamente a %s.', 'botwps-whatsapp-sender' ), esc_html( $recipient_phone ) ) . '</p></div>';
            } else {
                echo '<div id="message" class="notice notice-error is-dismissible botwps-notice"><p>' . sprintf( __( 'Error al enviar mensaje de WhatsApp a %s. Error: %s', 'botwps-whatsapp-sender' ), esc_html( $recipient_phone ), esc_html( $result['error'] ) ) . '</p></div>';
            }
        } else {
            echo '<div id="message" class="notice notice-error is-dismissible botwps-notice"><p>' . __( 'El número de teléfono del destinatario y el mensaje no pueden estar vacíos.', 'botwps-whatsapp-sender' ) . '</p></div>';
        }
    }

    $api_secret = get_option( 'botwps_api_secret' );
    $account_id = get_option( 'botwps_whatsapp_account_id' );

    if ( empty( $api_secret ) || empty( $account_id ) ) {
        $missing_settings = [];
        if (empty($api_secret)) $missing_settings[] = __('API Secret');
        if (empty($account_id)) $missing_settings[] = __('WhatsApp Account Unique ID');
        echo '<div class="notice notice-warning is-dismissible botwps-notice"><p>' . sprintf( __( 'Por favor, configura tu %s en la página de <a href="%s">Ajustes Generales</a> antes de enviar mensajes.', 'botwps-whatsapp-sender' ), implode( __( ' y ', 'botwps-whatsapp-sender' ), $missing_settings ), admin_url( 'admin.php?page=botwps-whatsapp-sender' ) ) . '</p></div>';
    } else {
    ?>
        <p><?php _e( 'Usa este formulario para enviar un mensaje de WhatsApp manualmente a través de la API de Botwps.com.', 'botwps-whatsapp-sender' ); ?></p>
        <form method="post" action="" class="botwps-send-form">
            <?php wp_nonce_field( 'botwps_manual_send_action', 'botwps_manual_send_nonce' ); ?>
            <table class="form-table botwps-form-table">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="botwps_recipient_phone"><?php _e( 'Número del Destinatario', 'botwps-whatsapp-sender' ); ?></label>
                        </th>
                        <td>
                            <input type="text" id="botwps_recipient_phone" name="botwps_recipient_phone" class="regular-text" required />
                            <p class="description"><?php _e( 'Incluye el código de país. Ej: 573001234567 para Colombia.', 'botwps-whatsapp-sender' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="botwps_message_text"><?php _e( 'Mensaje', 'botwps-whatsapp-sender' ); ?></label>
                        </th>
                        <td>
                            <textarea id="botwps_message_text" name="botwps_message_text" rows="5" class="large-text" required></textarea>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php submit_button( __( 'Enviar Mensaje de WhatsApp', 'botwps-whatsapp-sender' ), 'primary botwps-button', 'botwps_submit_manual_send' ); ?>
        </form>
    <?php } // Cierre del else para la comprobación de API Secret/Account ID ?>
    </div>
    <?php
}

/**
 * Función para enviar el mensaje de WhatsApp usando la API de Botwps.com.
 * Incluye logging y notificación de fallo por email.
 */
function botwps_send_actual_whatsapp_message( $recipient_phone, $message, $source_trigger = 'Desconocido' ) {
    global $wpdb;
    $log_table_name = $wpdb->prefix . 'botwps_whatsapp_log';

    $api_secret = get_option( 'botwps_api_secret' );
    $account_id = get_option( 'botwps_whatsapp_account_id' );

    $log_data = [
        'timestamp'      => current_time( 'mysql' ),
        'recipient'      => $recipient_phone,
        'message'        => $message,
        'status'         => 'failed', // Por defecto
        'api_response'   => '',
        'source_trigger' => $source_trigger,
    ];

    $return_data = ['success' => false, 'error' => '', 'response' => ''];

    if ( empty( $api_secret ) ) {
        $log_data['api_response'] = __( 'API Secret no configurado.', 'botwps-whatsapp-sender' );
        $return_data['error'] = $log_data['api_response'];
    } elseif ( empty( $account_id ) ) {
        $log_data['api_response'] = __( 'WhatsApp Account Unique ID no configurado.', 'botwps-whatsapp-sender' );
        $return_data['error'] = $log_data['api_response'];
    } else {
        $url = "https://panel2.botwps.com/api/send/whatsapp";
        $api_payload = [
            "secret"    => $api_secret,
            "account"   => $account_id,
            "recipient" => $recipient_phone,
            "type"      => "text",
            "message"   => $message
        ];

        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, $url );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query($api_payload) );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 15 ); // Aumentado ligeramente
        curl_setopt( $ch, CURLOPT_TIMEOUT, 45 );      // Aumentado ligeramente

        $response_body = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $curl_error = curl_error( $ch );
        curl_close( $ch );

        if ( $curl_error ) {
            $log_data['api_response'] = 'cURL Error: ' . $curl_error;
            $return_data['error'] = $log_data['api_response'];
        } else {
            $log_data['api_response'] = "HTTP Code: " . $http_code . ". Response: " . $response_body;
            $return_data['response'] = $response_body;

            if ( $http_code === 200 ) {
                $decoded_response = json_decode($response_body, true);
                // Ajusta 'status' y 'ok' según la respuesta real de éxito de la API de BotWPS
                if (isset($decoded_response['status']) && $decoded_response['status'] === 'ok') { // ASUNCIÓN: BotWPS devuelve {"status":"ok"} en éxito
                    $log_data['status'] = 'success';
                    $return_data['success'] = true;
                } else {
                    $log_data['api_response'] .= ' (Respuesta interna de API no indica éxito explícito: ' . esc_html($response_body) . ')';
                    $return_data['error'] = __( "Error en respuesta API (ver logs para detalles).", 'botwps-whatsapp-sender');
                }
            } else {
                $return_data['error'] = __( "Error HTTP (ver logs para detalles). Código: ", 'botwps-whatsapp-sender') . $http_code;
            }
        }
    }

    $wpdb->insert( $log_table_name, $log_data );

    if ( $log_data['status'] === 'failed' ) {
        $enable_failure_notify = get_option( 'botwps_enable_failure_notify', 0 );
        if ( $enable_failure_notify == 1 ) {
            $failure_email_address = get_option( 'botwps_failure_notify_email', get_option( 'admin_email' ) );
            if ( is_email( $failure_email_address ) ) {
                $subject = "[" . get_bloginfo('name') . "] " . __( 'Fallo al enviar mensaje de WhatsApp - BotWPS', 'botwps-whatsapp-sender' );
                $body = sprintf(
                    __( "Hubo un error al intentar enviar un mensaje de WhatsApp a través de BotWPS.\n\nDetalles:\n- Destinatario: %s\n- Origen: %s\n- Estado: %s\n- Respuesta API/Error: %s\n- Mensaje Intentado: \n%s\n\n- Fecha y Hora: %s (Hora del Servidor)\n- Sitio: %s", 'botwps-whatsapp-sender' ),
                    esc_html($log_data['recipient']),
                    esc_html($log_data['source_trigger']),
                    esc_html($log_data['status']),
                    esc_html($log_data['api_response']),
                    esc_html($log_data['message']),
                    esc_html($log_data['timestamp']),
                    esc_url(get_bloginfo('url'))
                );
                $headers = array('Content-Type: text/plain; charset=UTF-8');
                wp_mail( $failure_email_address, $subject, $body, $headers );
            }
        }
    }
    return $return_data;
}

/**
 * Muestra la página del log de mensajes.
 */
function botwps_render_log_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap botwps-admin-page-wrap botwps-log-page">
        <h1><?php echo esc_html__( 'Log de Mensajes WhatsApp', 'botwps-whatsapp-sender' ); ?></h1>
    <?php
    if ( ! class_exists( 'WP_List_Table' ) ) {
        require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
    }
    $list_table_file = BOTWPS_WHATSAPP_PLUGIN_PATH . 'includes/class-botwps-message-log-list-table.php';
    if ( file_exists( $list_table_file ) ) {
        require_once $list_table_file;
    } else {
        echo '<div class="notice notice-error botwps-notice"><p>' . __( 'Error: El archivo de la tabla de logs no se encuentra.', 'botwps-whatsapp-sender' ) . '</p></div>';
        echo '</div>'; // Cierra el div.wrap
        return;
    }

    if ( class_exists('BotWPS_Message_Log_List_Table') ) {
        $log_list_table = new BotWPS_Message_Log_List_Table();
        $log_list_table->prepare_items();
        // Para el campo de búsqueda
        echo '<form method="get">';
        echo '<input type="hidden" name="page" value="' . esc_attr($_REQUEST['page']) . '" />';
        $log_list_table->search_box( __( 'Buscar Logs', 'botwps-whatsapp-sender' ), 'botwps_log_search' );
        echo '</form>';
        $log_list_table->display();
    } else {
        echo '<div class="notice notice-error botwps-notice"><p>' . __( 'Error: La clase para la tabla de logs no está disponible.', 'botwps-whatsapp-sender' ) . '</p></div>';
    }
    echo '</div>'; // Cierra el div.wrap
}

/**
 * Cargar archivos de integración.
 */
function botwps_load_integrations() {
    // Integración con Gravity Forms
    if ( class_exists( 'GFCommon' ) ) {
        $gf_integration_file = BOTWPS_WHATSAPP_PLUGIN_PATH . 'includes/gravityforms-integration.php';
        if ( file_exists( $gf_integration_file ) ) {
            require_once $gf_integration_file;
            if ( class_exists( 'BotWPS_Gravity_Forms_Integration' ) ) {
                new BotWPS_Gravity_Forms_Integration();
            }
        }
    }

    // Integración con WooCommerce
    if ( class_exists( 'WooCommerce' ) ) {
        $wc_integration_file = BOTWPS_WHATSAPP_PLUGIN_PATH . 'includes/woocommerce-integration.php';
        if ( file_exists( $wc_integration_file ) ) {
            // require_once $wc_integration_file; // Descomentar cuando el archivo exista
            // if ( class_exists( 'BotWPS_WooCommerce_Integration' ) ) {
            // new BotWPS_WooCommerce_Integration();
            // }
            // GFCommon::log_debug( 'BotWPS: WooCommerce está activo, el archivo de integración se cargaría desde: ' . $wc_integration_file );
        }
    }

    // Shortcodes
    $shortcodes_file = BOTWPS_WHATSAPP_PLUGIN_PATH . 'includes/shortcodes.php';
    if ( file_exists( $shortcodes_file ) ) {
        // require_once $shortcodes_file; // Descomentar cuando el archivo exista
        // if ( class_exists( 'BotWPS_Shortcodes' ) ) {
        // new BotWPS_Shortcodes();
        // }
    }
}
add_action( 'plugins_loaded', 'botwps_load_integrations', 20 ); // Prioridad 20 para asegurar que GF/WC estén cargados

?>