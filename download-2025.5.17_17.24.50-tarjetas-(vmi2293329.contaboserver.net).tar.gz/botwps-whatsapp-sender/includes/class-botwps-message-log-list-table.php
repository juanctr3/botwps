<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente.
}

// Asegurarse de que la clase WP_List_Table esté disponible
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * BotWPS_Message_Log_List_Table Class.
 *
 * Maneja la visualización de la tabla de logs de mensajes de WhatsApp.
 */
class BotWPS_Message_Log_List_Table extends WP_List_Table {

    /**
     * Constructor.
     *
     * Configura los nombres singular y plural, y si es AJAX.
     */
    public function __construct() {
        parent::__construct( array(
            'singular' => __( 'Log de Mensaje WhatsApp', 'botwps-whatsapp-sender' ), // singular name of the listed records
            'plural'   => __( 'Logs de Mensajes WhatsApp', 'botwps-whatsapp-sender' ), // plural name of the listed records
            'ajax'     => false, // does this table support ajax?
        ) );
    }

    /**
     * Obtiene los logs de la base de datos.
     *
     * @param int $per_page Número de items por página.
     * @param int $page_number Número de la página actual.
     * @return array Array de logs.
     */
    public static function get_logs( $per_page = 20, $page_number = 1 ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'botwps_whatsapp_log';

        $sql = "SELECT * FROM {$table_name}";

        // Lógica de búsqueda (si se implementa un campo de búsqueda)
        if ( ! empty( $_REQUEST['s'] ) ) {
            $search = esc_sql( $wpdb->esc_like( $_REQUEST['s'] ) );
            $sql .= $wpdb->prepare( " WHERE recipient LIKE %s OR message LIKE %s OR source_trigger LIKE %s OR status LIKE %s", "%{$search}%", "%{$search}%", "%{$search}%", "%{$search}%" );
        }

        // Lógica de ordenación
        if ( ! empty( $_REQUEST['orderby'] ) ) {
            $orderby = sanitize_sql_orderby( $_REQUEST['orderby'] ); // Prevenir SQL injection en orderby
            $order = ( ! empty( $_REQUEST['order'] ) && in_array( strtoupper( $_REQUEST['order'] ), array( 'ASC', 'DESC' ) ) ) ? strtoupper( $_REQUEST['order'] ) : 'ASC';
            if ($orderby) { // Solo añadir si $orderby es válido
                 $sql .= " ORDER BY {$orderby} {$order}";
            }
        } else {
            $sql .= ' ORDER BY timestamp DESC'; // Por defecto ordenar por más reciente
        }

        $sql .= $wpdb->prepare( " LIMIT %d OFFSET %d", $per_page, ( $page_number - 1 ) * $per_page );

        return $wpdb->get_results( $sql, 'ARRAY_A' );
    }

    /**
     * Elimina un log específico por su ID.
     * (No se usa directamente en esta tabla, pero es útil si se implementan acciones)
     *
     * @param int $id ID del log a eliminar.
     */
    public static function delete_log( $id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'botwps_whatsapp_log';
        $wpdb->delete( $table_name, array( 'id' => $id ), array( '%d' ) );
    }

    /**
     * Obtiene el número total de logs.
     *
     * @return string|null Número total de logs, o null si hay error.
     */
    public static function record_count() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'botwps_whatsapp_log';
        
        $sql = "SELECT COUNT(*) FROM {$table_name}";
        
        // Aplicar filtro de búsqueda al conteo también
        if ( ! empty( $_REQUEST['s'] ) ) {
            $search = esc_sql( $wpdb->esc_like( $_REQUEST['s'] ) );
             $sql .= $wpdb->prepare( " WHERE recipient LIKE %s OR message LIKE %s OR source_trigger LIKE %s OR status LIKE %s", "%{$search}%", "%{$search}%", "%{$search}%", "%{$search}%" );
        }

        return $wpdb->get_var( $sql );
    }

    /**
     * Texto a mostrar cuando no hay items.
     */
    public function no_items() {
        _e( 'No hay logs de mensajes de WhatsApp todavía.', 'botwps-whatsapp-sender' );
    }

    /**
     * Renderiza el contenido por defecto de una columna si no hay un método específico.
     *
     * @param array $item Fila de datos.
     * @param string $column_name Nombre de la columna.
     * @return mixed Contenido de la celda.
     */
    function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'timestamp':
                return esc_html( get_date_from_gmt( $item[ $column_name ], 'Y-m-d H:i:s' ) ); // Convertir a hora local del sitio
            case 'recipient':
            case 'status':
            case 'source_trigger':
                return esc_html( $item[ $column_name ] );
            case 'message':
                // Mostrar solo una parte y el resto en un tooltip o al hacer clic (más avanzado)
                $message_trimmed = mb_strimwidth( $item[ $column_name ], 0, 100, "..." );
                return '<span title="' . esc_attr($item[$column_name]) . '">' . nl2br( esc_html( $message_trimmed ) ) . '</span>';
            case 'api_response':
                $response_trimmed = mb_strimwidth( $item[ $column_name ], 0, 150, "..." );
                 return '<span title="' . esc_attr($item[$column_name]) . '">' . nl2br( esc_html( $response_trimmed ) ) . '</span>';
            default:
                return esc_html( print_r( $item, true ) ); // Solo para debug, no debería llegar aquí
        }
    }

    /**
     * Renderiza la columna de checkbox.
     *
     * @param array $item Fila de datos.
     * @return string Checkbox HTML.
     */
    function column_cb( $item ) {
        return sprintf(
            '<input type="checkbox" name="bulk-delete[]" value="%s" />', $item['id']
        );
    }

    /**
     * Define las columnas de la tabla.
     *
     * @return array Array asociativo de columnas.
     */
    function get_columns() {
        $columns = array(
            'cb'             => '<input type="checkbox" />', // Para acciones masivas
            'timestamp'      => __( 'Fecha y Hora', 'botwps-whatsapp-sender' ),
            'recipient'      => __( 'Destinatario', 'botwps-whatsapp-sender' ),
            'message'        => __( 'Mensaje', 'botwps-whatsapp-sender' ),
            'status'         => __( 'Estado', 'botwps-whatsapp-sender' ),
            'source_trigger' => __( 'Origen', 'botwps-whatsapp-sender' ),
            'api_response'   => __( 'Respuesta API', 'botwps-whatsapp-sender' ),
        );
        return $columns;
    }

    /**
     * Define qué columnas son ordenables.
     *
     * @return array Array de columnas ordenables.
     */
    public function get_sortable_columns() {
        $sortable_columns = array(
            'timestamp'      => array( 'timestamp', true ), // true significa que es el orden por defecto (DESC)
            'recipient'      => array( 'recipient', false ),
            'status'         => array( 'status', false ),
            'source_trigger' => array( 'source_trigger', false ),
        );
        return $sortable_columns;
    }

    /**
     * Define las acciones masivas disponibles.
     * (Actualmente deshabilitado, pero aquí se definirían)
     *
     * @return array Array de acciones masivas.
     */
    public function get_bulk_actions() {
        // $actions = array(
        //    'bulk-delete' => __( 'Eliminar', 'botwps-whatsapp-sender' ),
        // );
        // return $actions;
        return array(); // Deshabilitado por ahora
    }

    /**
     * Procesa las acciones masivas.
     * (Se llamaría si se habilitan acciones masivas)
     */
    public function process_bulk_action() {
        // // Detecta cuándo se ha enviado una acción masiva
        // if ( 'delete' === $this->current_action() ) {
        //    // Verificar nonce
        //    // wp_verify_nonce( esc_attr( $_REQUEST['_wpnonce'] ), 'bws_delete_log_nonce' );
        //    // self::delete_log( absint( $_GET['log'] ) );
        // }

        // if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'bulk-delete' )
        // || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'bulk-delete' )
        // ) {
        //    $delete_ids = esc_sql( $_POST['bulk-delete'] );
        //    // loop over the array of record IDs and delete them
        //    foreach ( $delete_ids as $id ) {
        //        self::delete_log( $id );
        //    }
        //    // Redirigir con un mensaje de éxito (opcional)
        // }
    }

    /**
     * Prepara los items para mostrar en la tabla.
     *
     * Obtiene los datos, configura la paginación y los encabezados de columna.
     */
    public function prepare_items() {
        $this->_column_headers = $this->get_column_info();

        /** Procesar acciones masivas si se implementan */
        // $this->process_bulk_action();

        $per_page     = $this->get_items_per_page( 'logs_per_page', 20 ); // 20 items por página por defecto
        $current_page = $this->get_pagenum();
        $total_items  = self::record_count();

        $this->set_pagination_args( array(
            'total_items' => $total_items,                     // Número total de items
            'per_page'    => $per_page,                        // Número de items por página
            'total_pages' => ceil( $total_items / $per_page ), // Número total de páginas
        ) );

        $this->items = self::get_logs( $per_page, $current_page );
    }
}