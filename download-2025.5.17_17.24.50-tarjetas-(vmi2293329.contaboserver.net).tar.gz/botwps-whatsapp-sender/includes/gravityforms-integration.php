<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente.
}

// Verificar si Gravity Forms y sus componentes necesarios están activos.
if ( ! class_exists( 'GFCommon' ) || ! class_exists( 'GFAPI' ) || ! class_exists('GFFormSettings') ) {
    if ( defined('WP_DEBUG') && WP_DEBUG ) {
        error_log('BotWPS GF Integration: Clases requeridas de Gravity Forms no encontradas.');
    }
    return;
}

class BotWPS_Gravity_Forms_Integration {

    public function __construct() {
        add_filter( 'gform_form_settings_menu', array( $this, 'add_form_settings_menu_item' ), 10, 2 );
        add_action( 'gform_form_settings_page_botwps_whatsapp', array( $this, 'render_form_settings_page' ) );
        add_action( 'gform_after_submission', array( $this, 'process_form_submission' ), 10, 2 );

        // Encolar JS para la página de configuración
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
    }

    /**
     * Encola scripts JS para la página de configuración de BotWPS en Gravity Forms.
     */
    public function enqueue_admin_scripts( $hook_suffix ) {
        $screen = get_current_screen();
        if ( $screen && $screen->id === 'forms_page_gf_edit_forms' && isset( $_GET['subview'] ) && $_GET['subview'] === 'botwps_whatsapp' ) {
            wp_enqueue_script(
                'botwps-gf-settings-js',
                BOTWPS_WHATSAPP_PLUGIN_URL . 'includes/js/botwps-gf-settings.js', // Asegúrate que BOTWPS_WHATSAPP_PLUGIN_URL esté definido en el archivo principal
                array( 'jquery' ),
                defined('BOTWPS_WHATSAPP_VERSION') ? BOTWPS_WHATSAPP_VERSION : '1.0', // Usa la versión de tu plugin principal
                true
            );
        }
    }

    /**
     * Añade nuestro item al menú de configuración del formulario de Gravity Forms.
     */
    public function add_form_settings_menu_item( $menu_items, $form_id ) {
        $menu_items[] = array(
            'name'  => 'botwps_whatsapp',
            'label' => __( 'BotWPS WhatsApp', 'botwps-whatsapp-sender' ),
            'icon'  => 'dashicons-whatsapp',
        );
        return $menu_items;
    }

    /**
     * Muestra la página de configuración de BotWPS WhatsApp para un formulario.
     */
    public function render_form_settings_page( $form_param ) {
        // ---- INICIO DE CÓDIGO DE DEPURACIÓN TEMPORAL (Comentado por defecto) ----
        /*
        echo '<div style="background: #f0f0f0; border: 1px solid #ccc; padding: 10px; margin: 10px; font-family: monospace; font-size: 12px; z-index: 9999; position: relative;">';
        echo '<strong>DEBUG INFO (BotWPS Plugin - Eliminar después de depurar):</strong><br>';
        echo 'Type of $form_param: <pre style="white-space: pre-wrap; word-wrap: break-word;">' . esc_html(gettype($form_param)) . '</pre>';
        echo 'Value of $form_param: <pre style="white-space: pre-wrap; word-wrap: break-word;">';
        var_dump($form_param);
        echo '</pre>';
        echo '</div>';
        */
        // ---- FIN DE CÓDIGO DE DEPURACIÓN TEMPORAL ----

        $form = null;
        $form_id_to_load = null;

        if ( is_array( $form_param ) && ! empty( $form_param['id'] ) && is_numeric( $form_param['id'] ) ) {
            $form = $form_param;
        } elseif ( is_string( $form_param ) && is_numeric( $form_param ) && (int) $form_param > 0 ) {
            $form_id_to_load = (int) $form_param;
        } elseif ( is_int( $form_param ) && $form_param > 0 ) {
            $form_id_to_load = $form_param;
        } elseif ( ( is_string($form_param) && $form_param === "" ) || empty($form_param) ) {
            GFCommon::log_debug( __METHOD__ . '(): \$form_param was empty or an empty string. Attempting to get form ID from request.' );
            if ( class_exists('GFFormsModel') && method_exists('GFFormsModel', 'get_page_form_id') ) {
                 $current_form_id_from_request = GFFormsModel::get_page_form_id();
            } else {
                 $current_form_id_from_request = absint( rgget( 'id' ) );
            }
            if ( $current_form_id_from_request > 0 ) {
                GFCommon::log_debug( __METHOD__ . '(): Successfully retrieved form ID ' . $current_form_id_from_request . ' from request.' );
                $form_id_to_load = $current_form_id_from_request;
            } else {
                GFCommon::log_error( __METHOD__ . '(): \$form_param was empty, and could not retrieve a valid form ID from the request.' );
            }
        }

        if ( !is_null($form_id_to_load) ) {
            $form = GFAPI::get_form( $form_id_to_load );
            if ( ! $form ) {
                GFCommon::log_error( __METHOD__ . '(): Form ID ' . esc_html($form_id_to_load) . ' not found.' );
                echo "<div class='notice notice-error'><p>" . sprintf(__( 'Error: Formulario con ID %s no encontrado.', 'botwps-whatsapp-sender' ), esc_html($form_id_to_load)) . "</p></div>";
                return;
            }
        }

        if ( !is_array( $form ) || empty( $form['id'] ) ) {
            GFCommon::log_error( __METHOD__ . '(): Final check: Invalid or empty form object. Original \$form_param Type: ' . gettype($form_param) . '. Value: ' . print_r($form_param, true) );
            echo "<div class='notice notice-error'><p>" . __( 'Error: Parámetro de formulario inválido o vacío. Revise logs para más detalles.', 'botwps-whatsapp-sender' ) . "</p></div>";
            return;
        }

        $form_id = $form['id'];
        GFFormSettings::page_header( __( 'BotWPS WhatsApp Notificaciones', 'botwps-whatsapp-sender' ) );
    ?>
    <div class="botwps-gf-settings-wrap">
    <?php
        if ( rgpost( 'save' ) ) {
            // GFFormSettings::save_settings ya debería haber sido llamado por GF o se maneja con el submit
            // Verificar nonce si es necesario, aunque GF usualmente lo hace.
            // check_admin_referer('gforms_save_form_settings', 'gforms_save_form_settings');

            $form['botwps_whatsapp_settings'] = $this->get_posted_settings();
            $result = GFAPI::update_form( $form );
            if ( is_wp_error( $result ) ) {
                GFCommon::add_error_message( sprintf( __( 'Error al guardar configuración de BotWPS WhatsApp: %s', 'botwps-whatsapp-sender' ), $result->get_error_message() ) );
                GFCommon::log_error( __METHOD__ . '(): Failed to update form ' . $form_id . '. ' . $result->get_error_message() );
            } else {
                GFCommon::add_message( __( 'Configuración de BotWPS WhatsApp guardada exitosamente.', 'botwps-whatsapp-sender' ) );
                $form_reloaded = GFAPI::get_form( $form_id ); // Recargar para tener los datos más frescos
                 if ( is_array( $form_reloaded ) && ! empty( $form_reloaded['id'] ) ) {
                    $form = $form_reloaded;
                 } else {
                    GFCommon::log_error( __METHOD__ . '(): Failed to reload form object after saving settings for form ID: ' . $form_id );
                 }
            }
        }

        $settings = rgar( $form, 'botwps_whatsapp_settings' );
        $this->render_settings_fields( $settings, $form );
    ?>
    </div> <?php // Cierre de .botwps-gf-settings-wrap ?>
    <?php
        GFFormSettings::page_footer();
    }

    /**
     * Obtiene los datos enviados por POST para la configuración y los sanitiza.
     */
    private function get_posted_settings() {
        $settings = array(
            'admin_enable'         => isset( $_POST['botwps_admin_enable'] ) ? true : false,
            'admin_phones'         => sanitize_textarea_field( rgpost( 'botwps_admin_phones' ) ),
            'admin_message'        => wp_kses_post( rgpost( 'botwps_admin_message' ) ), // Permitir HTML básico seguro
            'admin_cond_enable'    => isset( $_POST['botwps_admin_cond_enable'] ) ? true : false,
            'admin_cond_field'     => sanitize_text_field( rgpost( 'botwps_admin_cond_field' ) ),
            'admin_cond_operator'  => sanitize_text_field( rgpost( 'botwps_admin_cond_operator' ) ),
            'admin_cond_value'     => sanitize_text_field( rgpost( 'botwps_admin_cond_value' ) ),

            'client_enable'        => isset( $_POST['botwps_client_enable'] ) ? true : false,
            'client_phone_field'   => sanitize_text_field( rgpost( 'botwps_client_phone_field' ) ),
            'client_message'       => wp_kses_post( rgpost( 'botwps_client_message' ) ), // Permitir HTML básico seguro
            'client_optin_field'   => sanitize_text_field( rgpost( 'botwps_client_optin_field' ) ),
            'client_optin_value'   => sanitize_text_field( rgpost( 'botwps_client_optin_value' ) ),
            'client_cond_enable'   => isset( $_POST['botwps_client_cond_enable'] ) ? true : false,
            'client_cond_field'    => sanitize_text_field( rgpost( 'botwps_client_cond_field' ) ),
            'client_cond_operator' => sanitize_text_field( rgpost( 'botwps_client_cond_operator' ) ),
            'client_cond_value'    => sanitize_text_field( rgpost( 'botwps_client_cond_value' ) ),
        );
        return $settings;
    }

    /**
     * Genera la lista de merge tags disponibles para un formulario.
     */
    private function get_merge_tags_for_form( $form ) {
        $tags = array(
            '{form_id}' => __('ID del Formulario', 'botwps-whatsapp-sender'),
            '{form_title}' => __('Título del Formulario', 'botwps-whatsapp-sender'),
            '{entry_id}' => __('ID de la Entrada', 'botwps-whatsapp-sender'),
            '{entry_url}' => __('URL de la Entrada (Admin)', 'botwps-whatsapp-sender'),
            '{date_mdy}' => __('Fecha (MM/DD/YYYY)', 'botwps-whatsapp-sender'),
            '{date_dmy}' => __('Fecha (DD/MM/YYYY)', 'botwps-whatsapp-sender'),
            '{time}' => __('Hora (HH:MM Formato 24h)', 'botwps-whatsapp-sender'),
            '{ip}' => __('Dirección IP del Usuario', 'botwps-whatsapp-sender'),
            '{user_agent}' => __('Agente de Usuario', 'botwps-whatsapp-sender'),
            '{admin_email}' => __('Email del Administrador del Sitio', 'botwps-whatsapp-sender'),
            '{all_fields}' => __('Todos los Campos Enviados', 'botwps-whatsapp-sender'),
            '{user:display_name}' => __('Nombre Visible del Usuario (si está logueado)', 'botwps-whatsapp-sender'),
            '{user:user_email}' => __('Email del Usuario (si está logueado)', 'botwps-whatsapp-sender'),
            '{user:user_login}' => __('Login del Usuario (si está logueado)', 'botwps-whatsapp-sender'),
            // Podrías añadir más merge tags comunes de GF
        );

        if ( is_array( $form['fields'] ) ) {
            foreach ( $form['fields'] as $field ) {
                if ( ! is_object( $field ) ) continue; // Seguridad extra

                $field_id = $field->id;
                // Usar adminLabel si está disponible y no vacío, sino label
                $field_label = !empty( $field->adminLabel ) ? $field->adminLabel : $field->label;
                $field_label_sanitized = sanitize_title( $field_label ); // Para crear un tag más legible si es posible
                
                // Tag usando el label (si existe) y el ID
                if ( !empty($field_label) ) {
                     $tags["{{$field_label}:{$field_id}}"] = esc_html( $field_label ) . ' (ID: ' . $field_id . ')';
                }
                // Tag usando solo el ID (siempre disponible)
                $tags["{{$field_id}}"] = sprintf(__( 'Campo con ID: %d (%s)', 'botwps-whatsapp-sender' ), $field_id, esc_html( $field_label ?: $field->type ) );

                // Para campos con múltiples inputs (nombre, dirección, checkbox, etc.)
                if (is_array($field->inputs)) {
                    foreach ($field->inputs as $input) {
                        // La forma correcta de obtener el label de un input es a través de GFCommon::get_label($field, $input['id'])
                        // $input_label = GFCommon::get_label($field, $input['id'], false); // No mostrar "Campo:" antes
                        $input_id_parts = explode('.', $input['id']);
                        $input_id_for_tag = end($input_id_parts); // Usar solo la parte después del punto para el tag.
                        
                        // Usar el label del input si existe
                        $input_display_label = !empty( $input['customLabel'] ) ? $input['customLabel'] : ( !empty( $input['label'] ) ? $input['label'] : $input_id_for_tag );

                        $tags["{{$field_label}:{$input['id']}}"] = esc_html( $field_label ) . ' - ' . esc_html( $input_display_label ) . ' (ID: ' . $input['id'] . ')';
                        $tags["{{$input['id']}}"] = sprintf(__( 'Subcampo ID: %s (%s)', 'botwps-whatsapp-sender' ), $input['id'], esc_html($input_display_label) );
                    }
                }
            }
        }
        ksort($tags); // Ordenar alfabéticamente por tag
        return $tags;
    }

    /**
     * Muestra la lista de merge tags como HTML.
     */
    private function display_merge_tag_list($form) {
        $merge_tags = $this->get_merge_tags_for_form($form);
        if (empty($merge_tags)) {
            return;
        }
        echo '<div class="botwps-merge-tag-list">'; // La clase principal para estilos CSS
        echo '<p class="merge-tag-list-title"><strong>' . __('Variables disponibles (clic para insertar):', 'botwps-whatsapp-sender') . '</strong></p>';
        echo '<ul class="merge-tag-ul">';
        foreach ($merge_tags as $tag => $label) {
            echo '<li><a href="#" class="merge-tag-link" data-tag="' . esc_attr($tag) . '">' . esc_html($tag) . '</a> &ndash; <small class="merge-tag-label">' . esc_html($label) . '</small></li>';
        }
        echo '</ul></div>';
    }

    /**
     * Muestra los campos de configuración HTML.
     */
    private function render_settings_fields( $settings, $form ) {
        $api_secret = get_option( 'botwps_api_secret' );
        $account_id = get_option( 'botwps_whatsapp_account_id' );

        if ( empty( $api_secret ) || empty( $account_id ) ) {
            $missing_global_settings = [];
            if (empty($api_secret)) $missing_global_settings[] = __('API Secret', 'botwps-whatsapp-sender');
            if (empty($account_id)) $missing_global_settings[] = __('WhatsApp Account Unique ID', 'botwps-whatsapp-sender');
            echo '<div class="notice notice-error botwps-notice"><p>' .
                 wp_kses_post(sprintf( __( 'Por favor, configura primero tu %s en la <a href="%s">página de configuración general de BotWPS WhatsApp</a> para poder usar esta integración.', 'botwps-whatsapp-sender' ),
                 implode( __( ' y ', 'botwps-whatsapp-sender' ), $missing_global_settings ),
                 esc_url( admin_url( 'admin.php?page=botwps-whatsapp-sender' ) ) )) .
                 '</p></div>';
        }

        $conditional_operators = array(
            'is' => __('Es', 'botwps-whatsapp-sender'),
            'isnot' => __('No es', 'botwps-whatsapp-sender'),
            'contains' => __('Contiene', 'botwps-whatsapp-sender'),
            'starts_with' => __('Comienza con', 'botwps-whatsapp-sender'),
            'ends_with' => __('Termina con', 'botwps-whatsapp-sender'),
            '>' => __('Mayor que (numérico)', 'botwps-whatsapp-sender'),
            '<' => __('Menor que (numérico)', 'botwps-whatsapp-sender'),
            'is_empty' => __('Está vacío', 'botwps-whatsapp-sender'),
            'is_not_empty' => __('No está vacío', 'botwps-whatsapp-sender'),
        );
        ?>
        <form method="post" id="gform_form_settings_botwps" class="botwps-gf-sub-settings-form">
            <?php // wp_nonce_field( 'gforms_save_form_settings', 'gforms_save_form_settings' ); // GF lo maneja ?>
            
            <div class="gform_settings_panel">
                <h4 class="gform_settings_panel_title"><?php _e( 'Notificaciones para Administradores', 'botwps-whatsapp-sender' ); ?></h4>
                <div class="gform_settings_panel_content">
                    <table class="gforms_form_settings">
                        <tr>
                            <th><label for="botwps_admin_enable"><?php _e( 'Activar Notificación para Admin', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_admin_enable_tt' ) ?></th>
                            <td><input type="checkbox" name="botwps_admin_enable" id="botwps_admin_enable" value="1" <?php checked( rgar( $settings, 'admin_enable' ), true ); ?> /></td>
                        </tr>
                        <tr>
                            <th><label for="botwps_admin_phones"><?php _e( 'Números de Teléfono del Admin', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_admin_phones_tt' ) ?></th>
                            <td>
                                <textarea name="botwps_admin_phones" id="botwps_admin_phones" class="medium-text" rows="3"><?php echo esc_textarea( rgar( $settings, 'admin_phones' ) ); ?></textarea>
                                <p class="description"><?php _e( 'Separados por comas. Incluye código de país.', 'botwps-whatsapp-sender' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="botwps_admin_message_textarea"><?php _e( 'Mensaje para el Admin', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_admin_message_tt' ) ?></th>
                            <td>
                                <textarea name="botwps_admin_message" id="botwps_admin_message_textarea" class="large-text code botwps-message-template" rows="5"><?php echo esc_textarea( rgar( $settings, 'admin_message', __( "Nuevo envío del formulario '{form_title}' (ID de Entrada: {entry_id}):\n{all_fields}", 'botwps-whatsapp-sender' ) ) ); ?></textarea>
                                <?php $this->display_merge_tag_list($form); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="botwps_admin_cond_enable"><?php _e( 'Activar Lógica Condicional', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_admin_cond_enable_tt' ) ?></th>
                            <td><input type="checkbox" name="botwps_admin_cond_enable" id="botwps_admin_cond_enable" value="1" <?php checked( rgar( $settings, 'admin_cond_enable' ), true ); ?> /></td>
                        </tr>
                        <tr class="botwps_admin_conditional_row conditional-logic-row" <?php echo rgar( $settings, 'admin_cond_enable' ) ? '' : 'style="display:none;"'; ?>>
                            <th><?php _e( 'Condición de Envío', 'botwps-whatsapp-sender' ); ?></th>
                            <td class="conditional-logic-container">
                                <span class="conditional-label"><?php _e('Enviar si', 'botwps-whatsapp-sender'); ?></span>
                                <select name="botwps_admin_cond_field">
                                    <option value=""><?php _e('-- Seleccionar Campo --', 'botwps-whatsapp-sender');?></option>
                                    <?php foreach ($form['fields'] as $field) : if(!is_object($field)) continue; /** @var GF_Field $field */ ?>
                                        <option value="<?php echo esc_attr($field->id); ?>" <?php selected(rgar($settings, 'admin_cond_field'), $field->id); ?>><?php echo esc_html(GFCommon::get_label($field)); ?> (ID: <?php echo esc_html($field->id); ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="botwps_admin_cond_operator">
                                    <?php foreach ($conditional_operators as $op_val => $op_label) : ?>
                                        <option value="<?php echo esc_attr($op_val); ?>" <?php selected(rgar($settings, 'admin_cond_operator'), $op_val); ?>><?php echo esc_html($op_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="botwps_admin_cond_value" value="<?php echo esc_attr(rgar($settings, 'admin_cond_value')); ?>" placeholder="<?php esc_attr_e('Valor', 'botwps-whatsapp-sender'); ?>"/>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="gform_settings_panel">
                <h4 class="gform_settings_panel_title"><?php _e( 'Notificaciones para el Cliente', 'botwps-whatsapp-sender' ); ?></h4>
                <div class="gform_settings_panel_content">
                    <table class="gforms_form_settings">
                        <tr>
                            <th><label for="botwps_client_enable"><?php _e( 'Activar Notificación para Cliente', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_client_enable_tt' ) ?></th>
                            <td><input type="checkbox" name="botwps_client_enable" id="botwps_client_enable" value="1" <?php checked( rgar( $settings, 'client_enable' ), true ); ?> /></td>
                        </tr>
                        <tr>
                            <th><label for="botwps_client_phone_field"><?php _e( 'Campo de Teléfono del Cliente', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_client_phone_field_tt' ) ?></th>
                            <td>
                                <select name="botwps_client_phone_field" id="botwps_client_phone_field" class="gform_select">
                                    <option value=""><?php _e( '-- Seleccionar Campo de Teléfono --', 'botwps-whatsapp-sender' ); ?></option>
                                    <?php foreach ( $form['fields'] as $field ) : if(!is_object($field)) continue; /** @var GF_Field $field */ ?>
                                        <?php if ( $field->get_input_type() == 'phone' || $field->type == 'phone' || $field->get_input_type() == 'text' || $field->get_input_type() == 'number' ): ?>
                                            <option value="<?php echo esc_attr( $field->id ); ?>" <?php selected( rgar( $settings, 'client_phone_field' ), $field->id ); ?>><?php echo esc_html( GFCommon::get_label( $field ) . ' (ID: ' . $field->id . ')' ); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="botwps_client_message_textarea"><?php _e( 'Mensaje para el Cliente', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_client_message_tt' ) ?></th>
                            <td>
                                <textarea name="botwps_client_message" id="botwps_client_message_textarea" class="large-text code botwps-message-template" rows="5"><?php echo esc_textarea( rgar( $settings, 'client_message', __( "¡Gracias {Nombre:1} por tu envío en '{form_title}'!", 'botwps-whatsapp-sender' ) ) ); ?></textarea>
                                <?php $this->display_merge_tag_list($form); ?>
                            </td>
                        </tr>
                         <tr>
                            <th><label for="botwps_client_optin_field"><?php _e( 'Campo de Opt-In para Cliente', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_client_optin_field_tt' ) ?></th>
                            <td>
                                <select name="botwps_client_optin_field" id="botwps_client_optin_field" class="gform_select">
                                    <option value=""><?php _e( '-- Sin Opt-In Obligatorio --', 'botwps-whatsapp-sender' ); ?></option>
                                    <?php foreach ( $form['fields'] as $field ) : if(!is_object($field)) continue; /** @var GF_Field $field */ ?>
                                        <?php if ( in_array($field->get_input_type(), array('checkbox', 'radio', 'select', 'consent')) || $field->type == 'consent' ): // 'consent' es un tipo de campo específico de GF ?>
                                            <option value="<?php echo esc_attr( $field->id ); ?>" <?php selected( rgar( $settings, 'client_optin_field' ), $field->id ); ?>><?php echo esc_html( GFCommon::get_label( $field ) . ' (ID: ' . $field->id . ')' ); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                                 <input type="text" name="botwps_client_optin_value" value="<?php echo esc_attr(rgar($settings, 'client_optin_value', '1')); ?>" placeholder="<?php esc_attr_e('Valor para Opt-In', 'botwps-whatsapp-sender'); ?>" style="width:150px; margin-left:10px;"/>
                                <p class="description"><?php _e('Si se selecciona un campo, el mensaje al cliente solo se enviará si el valor de este campo coincide con el "Valor para Opt-In". Para checkboxes, el valor puede ser el "value" de la opción o su etiqueta si "value" no está definido. Por defecto, "1" se usa comúnmente para "sí" o "marcado".', 'botwps-whatsapp-sender');?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="botwps_client_cond_enable"><?php _e( 'Activar Lógica Condicional', 'botwps-whatsapp-sender' ); ?></label> <?php gform_tooltip( 'form_botwps_client_cond_enable_tt' ) ?></th>
                            <td><input type="checkbox" name="botwps_client_cond_enable" id="botwps_client_cond_enable" value="1" <?php checked( rgar( $settings, 'client_cond_enable' ), true ); ?> /></td>
                        </tr>
                         <tr class="botwps_client_conditional_row conditional-logic-row" <?php echo rgar( $settings, 'client_cond_enable' ) ? '' : 'style="display:none;"'; ?>>
                            <th><?php _e( 'Condición de Envío', 'botwps-whatsapp-sender' ); ?></th>
                            <td class="conditional-logic-container">
                                <span class="conditional-label"><?php _e('Enviar si', 'botwps-whatsapp-sender'); ?></span>
                                <select name="botwps_client_cond_field">
                                   <option value=""><?php _e('-- Seleccionar Campo --', 'botwps-whatsapp-sender');?></option>
                                    <?php foreach ($form['fields'] as $field) : if(!is_object($field)) continue; /** @var GF_Field $field */ ?>
                                        <option value="<?php echo esc_attr($field->id); ?>" <?php selected(rgar($settings, 'client_cond_field'), $field->id); ?>><?php echo esc_html(GFCommon::get_label($field)); ?> (ID: <?php echo esc_html($field->id); ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                                <select name="botwps_client_cond_operator">
                                    <?php foreach ($conditional_operators as $op_val => $op_label) : ?>
                                        <option value="<?php echo esc_attr($op_val); ?>" <?php selected(rgar($settings, 'client_cond_operator'), $op_val); ?>><?php echo esc_html($op_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="botwps_client_cond_value" value="<?php echo esc_attr(rgar($settings, 'client_cond_value')); ?>" placeholder="<?php esc_attr_e('Valor', 'botwps-whatsapp-sender'); ?>"/>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <button type="submit" name="save" value="save" class="button button-primary botwps-button">
                <?php _e( 'Guardar Configuración de WhatsApp', 'botwps-whatsapp-sender' ); ?>
            </button>
        </form>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                function toggleConditionalRows(checkboxId, rowClass) {
                    var $checkbox = $('#' + checkboxId);
                    var $row = $('.' + rowClass); // Busca por clase
                    if ($checkbox.is(':checked')) {
                        $row.show();
                    } else {
                        $row.hide();
                    }
                }

                // Al cargar la página
                toggleConditionalRows('botwps_admin_cond_enable', 'botwps_admin_conditional_row');
                toggleConditionalRows('botwps_client_cond_enable', 'botwps_client_conditional_row');

                // Al cambiar el checkbox
                $('#botwps_admin_cond_enable').on('change', function() {
                    toggleConditionalRows('botwps_admin_cond_enable', 'botwps_admin_conditional_row');
                });

                $('#botwps_client_cond_enable').on('change', function() {
                    toggleConditionalRows('botwps_client_cond_enable', 'botwps_client_conditional_row');
                });
            });
        </script>
        <?php
         gform_initialize_tooltips(); // Para los tooltips (?) de Gravity Forms
    }

    /**
     * Evalúa una condición basada en el valor de una entrada, un operador y un valor de regla.
     */
    private function evaluate_condition($entry_value, $operator, $rule_value) {
        $is_numeric_comparison = in_array($operator, array('>', '<'));
        $entry_is_numeric = is_numeric($entry_value);
        $rule_is_numeric = is_numeric($rule_value);

        // Para 'is_empty' y 'is_not_empty', el $rule_value no se usa.
        if ($operator === 'is_empty') {
            return $entry_value === null || $entry_value === '';
        }
        if ($operator === 'is_not_empty') {
            return $entry_value !== null && $entry_value !== '';
        }
        
        // Si se espera comparación numérica pero alguno no es numérico, tratar con cuidado.
        if ($is_numeric_comparison) {
            if (!$entry_is_numeric || !$rule_is_numeric) {
                // Si uno no es numérico en una comparación numérica, generalmente es falso,
                // a menos que quieras forzar conversiones, lo cual puede ser riesgoso.
                GFCommon::log_debug( "[BotWPS GF] Conditional logic: Numeric comparison attempted with non-numeric values. Entry: '{$entry_value}', Rule: '{$rule_value}'" );
                return false; 
            }
            $entry_value = (float) $entry_value;
            $rule_value = (float) $rule_value;
        } else {
            // Para comparaciones de texto, convertir ambos a string y a minúsculas para insensibilidad a may/min.
            $entry_value = strtolower( (string) $entry_value );
            $rule_value = strtolower( (string) $rule_value );
        }

        switch ($operator) {
            case 'is':          return $entry_value == $rule_value; // Ya en minúsculas si es texto
            case 'isnot':       return $entry_value != $rule_value; // Ya en minúsculas si es texto
            case 'contains':    return strpos( $entry_value, $rule_value ) !== false; // Ya en minúsculas
            case 'starts_with': return strpos( $entry_value, $rule_value ) === 0;     // Ya en minúsculas
            case 'ends_with':
                $rule_len = strlen( $rule_value );
                if ($rule_len == 0) return true;
                return substr( $entry_value, -$rule_len ) === $rule_value; // Ya en minúsculas
            case '>':           return $entry_value > $rule_value;  // Numérico
            case '<':           return $entry_value < $rule_value;  // Numérico
            // is_empty e is_not_empty ya se manejaron arriba.
            default:
                GFCommon::log_debug( "[BotWPS GF] Conditional logic: Unknown operator '{$operator}'" );
                return false;
        }
    }

    /**
     * Procesa el envío del formulario para enviar notificaciones de WhatsApp.
     */
    public function process_form_submission( $entry, $form ) {
        $settings = rgar( $form, 'botwps_whatsapp_settings' );
        $api_secret = get_option( 'botwps_api_secret' );
        $account_id = get_option( 'botwps_whatsapp_account_id' );

        if ( empty( $api_secret ) || empty( $account_id ) ) {
            error_log('[BotWPS GF] API Secret/Account ID no configurados globalmente. Form ID: ' . $form['id'] . ', Entry ID: ' . $entry['id']);
            return;
        }

        $source_trigger_base = sprintf( __( 'Gravity Form ID: %d, Título: %s', 'botwps-whatsapp-sender' ), $form['id'], $form['title'] );

        // Notificación para el Administrador
        if ( rgar( $settings, 'admin_enable' ) && ! empty( rgar( $settings, 'admin_phones' ) ) && ! empty( rgar( $settings, 'admin_message' ) ) ) {
            $send_admin_notification = true;
            if ( rgar( $settings, 'admin_cond_enable' ) ) {
                $field_id = rgar( $settings, 'admin_cond_field' );
                $operator = rgar( $settings, 'admin_cond_operator' );
                $value    = rgar( $settings, 'admin_cond_value' );
                if ( !empty($field_id) && !empty($operator) ) { // Solo evaluar si hay campo y operador
                    $entry_value = GFFormsModel::get_lead_field_value( $entry, GFAPI::get_field( $form, $field_id ) );
                    if ( !$this->evaluate_condition( $entry_value, $operator, $value ) ) {
                        $send_admin_notification = false;
                        GFCommon::log_debug( "[BotWPS GF] Admin notification skipped due to conditional logic. Form ID {$form['id']}, Entry ID {$entry['id']}" );
                    }
                } else {
                     GFCommon::log_debug( "[BotWPS GF] Admin conditional logic enabled but field or operator not set. Form ID {$form['id']}" );
                }
            }

            if ( $send_admin_notification ) {
                $admin_phones_str = rgar( $settings, 'admin_phones' );
                $admin_phone_numbers = array_map( 'trim', explode( ',', $admin_phones_str ) );
                $admin_message_template = rgar( $settings, 'admin_message' );
                $processed_admin_message = GFCommon::replace_variables( $admin_message_template, $form, $entry, false, true, false, 'text' );
                $source_admin = $source_trigger_base . __( ' (Admin)', 'botwps-whatsapp-sender' );

                foreach ( $admin_phone_numbers as $admin_phone ) {
                    if ( ! empty( $admin_phone ) ) {
                        if ( function_exists( 'botwps_send_actual_whatsapp_message' ) ) {
                            botwps_send_actual_whatsapp_message( $admin_phone, $processed_admin_message, $source_admin );
                        } else {
                            error_log('[BotWPS GF Admin] Error: botwps_send_actual_whatsapp_message no existe.');
                        }
                    }
                }
            }
        }

        // Notificación para el Cliente
        if ( rgar( $settings, 'client_enable' ) && ! empty( rgar( $settings, 'client_phone_field' ) ) && ! empty( rgar( $settings, 'client_message' ) ) ) {
            $send_client_notification = true;

            // 1. Comprobar Opt-In
            $optin_field_id = rgar( $settings, 'client_optin_field' );
            if ( !empty( $optin_field_id ) ) {
                $optin_value_expected = rgar( $settings, 'client_optin_value', '1' );
                $optin_field_object = GFAPI::get_field( $form, $optin_field_id );
                $entry_optin_value = GFFormsModel::get_lead_field_value( $entry, $optin_field_object );
                $is_opted_in = false;

                if ($optin_field_object && $optin_field_object->type == 'checkbox' && is_array($optin_field_object->choices)) {
                    // Para checkboxes, el valor de entrada es un array de las opciones seleccionadas (o sus valores)
                    // O si es un solo checkbox, el valor es el 'value' de ese input
                    if (is_array($entry_optin_value)) { // Múltiples checkboxes
                        foreach ($entry_optin_value as $checked_value) {
                            if (strtolower( (string) $checked_value ) == strtolower( (string) $optin_value_expected )) {
                                $is_opted_in = true; break;
                            }
                        }
                    } else { // Un solo checkbox o valor directo
                         if (strtolower( (string) $entry_optin_value ) == strtolower( (string) $optin_value_expected )) {
                            $is_opted_in = true;
                         }
                    }
                } else { // Para otros tipos de campo (radio, select, text, consent)
                    if ( strtolower( (string) $entry_optin_value ) == strtolower( (string) $optin_value_expected ) ) {
                        $is_opted_in = true;
                    }
                }
                
                if (!$is_opted_in) {
                    $send_client_notification = false;
                    GFCommon::log_debug( "[BotWPS GF] Client notification skipped due to opt-in. Form ID {$form['id']}, Entry ID {$entry['id']}. Field {$optin_field_id}, Expected '{$optin_value_expected}', Got '{$entry_optin_value}'" );
                }
            }

            // 2. Comprobar Lógica Condicional del Cliente si aún se debe enviar
            if ( $send_client_notification && rgar( $settings, 'client_cond_enable' ) ) {
                $field_id = rgar( $settings, 'client_cond_field' );
                $operator = rgar( $settings, 'client_cond_operator' );
                $value    = rgar( $settings, 'client_cond_value' );
                if ( !empty($field_id) && !empty($operator) ) {
                    $entry_value = GFFormsModel::get_lead_field_value( $entry, GFAPI::get_field( $form, $field_id ) );
                    if ( !$this->evaluate_condition( $entry_value, $operator, $value ) ) {
                        $send_client_notification = false;
                         GFCommon::log_debug( "[BotWPS GF] Client notification skipped due to conditional logic. Form ID {$form['id']}, Entry ID {$entry['id']}" );
                    }
                } else {
                    GFCommon::log_debug( "[BotWPS GF] Client conditional logic enabled but field or operator not set. Form ID {$form['id']}" );
                }
            }

            if ( $send_client_notification ) {
                $client_phone_field_id = rgar( $settings, 'client_phone_field' );
                $client_phone_object = GFAPI::get_field( $form, $client_phone_field_id );
                $client_phone_number = GFFormsModel::get_lead_field_value( $entry, $client_phone_object );

                $client_message_template = rgar( $settings, 'client_message' );
                $source_client = $source_trigger_base . __( ' (Cliente)', 'botwps-whatsapp-sender' );

                if ( ! empty( $client_phone_number ) && strlen( (string) $client_phone_number ) > 5 ) {
                    $processed_client_message = GFCommon::replace_variables( $client_message_template, $form, $entry, false, true, false, 'text' );
                     if ( function_exists( 'botwps_send_actual_whatsapp_message' ) ) {
                        botwps_send_actual_whatsapp_message( $client_phone_number, $processed_client_message, $source_client );
                    } else {
                        error_log('[BotWPS GF Client] Error: botwps_send_actual_whatsapp_message no existe.');
                    }
                } else {
                     error_log('[BotWPS GF] Client notification skipped: Teléfono vacío/inválido. Form ID ' . $form['id'] . ', Entry ID ' . $entry['id'] . ', Field ID: ' . $client_phone_field_id . ', Valor: ' . $client_phone_number);
                }
            }
        }
    }
} // Fin de la clase BotWPS_Gravity_Forms_Integration

?>