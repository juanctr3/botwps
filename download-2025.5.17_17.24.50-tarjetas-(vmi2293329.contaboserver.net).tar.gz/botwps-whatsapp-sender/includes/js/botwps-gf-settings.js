jQuery(document).ready(function($) {
    var $lastFocusedTextarea = null;

    // Guardar la última textarea enfocada
    $('textarea.botwps-message-template').on('focus', function() {
        $lastFocusedTextarea = $(this);
    });

    // Insertar merge tag al hacer clic
    $('.botwps-merge-tag-list .merge-tag-link').on('click', function(e) {
        e.preventDefault();
        var mergeTag = $(this).data('tag');
        var $targetTextarea = $lastFocusedTextarea;

        // Si no hay una textarea enfocada recientemente, intentar encontrar una cercana (fallback)
        if (!$targetTextarea) {
            $targetTextarea = $(this).closest('td').find('textarea.botwps-message-template');
        }
         if (!$targetTextarea || $targetTextarea.length === 0) { // Si aún no se encuentra, no hacer nada
            // Quizás alertar al usuario para que primero haga clic en un campo de mensaje
            // alert('Por favor, haz clic primero en el campo de mensaje donde quieres insertar la variable.');
            console.warn('BotWPS: No message textarea focused or found for merge tag insertion.');
            return;
        }


        var cursorPos = $targetTextarea.prop('selectionStart');
        var text = $targetTextarea.val();
        var newText = text.substring(0, cursorPos) + mergeTag + text.substring(cursorPos);

        $targetTextarea.val(newText);
        $targetTextarea.focus(); // Devolver el foco
        $targetTextarea.prop('selectionStart', cursorPos + mergeTag.length);
        $targetTextarea.prop('selectionEnd', cursorPos + mergeTag.length);
    });
});